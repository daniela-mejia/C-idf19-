#include <stdio.h>
#include <string.h>
#include "MyStringHeader.c"
#include "MyStringHeader.h"

extern int reverse_it(char * forwardString, int strLen);

int main ()
{
/* Print a non-null terminated string backwards and then print a newline

    Write a program that reads a string from user input, call reverse_it(), and then call print_the_count()
    When satisfied, run "Unit Test Code 2.c"
*/
    char Array [256] = {0};
    char *StringSecond = {Array};
    
    printf( "write an array you want to reverse: \n");    // ask User for an array 
  
    scanf("%255[^\n]s", &Array);      //scan for the user Input 
    
     
    reverse_it(StringSecond, strlen(Array));  // use reverse_it function from MyStringHeader.c
    printf( "\n %d\n", &Array);  //print the reverse user input 

    return 0;
    
}



