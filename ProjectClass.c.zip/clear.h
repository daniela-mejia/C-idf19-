#ifdef _WIN32
#define CLEAR "cls"
#include <conio.h> // Allows the use of console input/output
#endif