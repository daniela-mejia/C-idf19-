# ask input distance in km to miles

kilometers = float(input(" Give me a distance in km: "))
miles= kilometers * 0.6214
print(" This is your distance in miles: %.2f" %(miles))
