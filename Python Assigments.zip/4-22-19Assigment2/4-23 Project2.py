#This program draws several text figures, including
#a diamond, an X and a rocket ship

def draw_diamond():
    print ("    /\\")
    print ("   /  \\")
    print ("  /    \\")
    print ("  \\    /")
    print ("   \\  /")
    print ("    \\/")
    print ()
    
