
def main():
    time= int(input(" Input a number that will be multiply by 10= "))
    diez= time*10
    print("Output= %d" %(diez))
    show_value = 12

def show_value(quantity):
    print (show_value)

main()
    
