
def main ():
       
    for i in range(5):
        if i==0:
            i=i+1
        print("2 times ", i,"=", i*2)            
main()
