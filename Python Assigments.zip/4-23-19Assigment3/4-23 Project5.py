def main():
    x=101
    if x>100 :
        print ("y=20 and x=40")
    a = 9
    if a<10 :
        print ("b=0 and c=1")
    else:
        print ("b=99")
main()
        

    
        
