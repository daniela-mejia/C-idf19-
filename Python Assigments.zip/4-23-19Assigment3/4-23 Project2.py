num = [1,4,9,16,25,36,49,64,81,100]
for number in num:
    print(number)
