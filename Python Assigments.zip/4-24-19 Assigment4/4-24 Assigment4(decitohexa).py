#write  a program change from decimal to hexadecimal

decimal= int (input("Enter a decimal number to be convert to hexadecimal: "))

hexa= hex(decimal)

print ("Convert number" , decimal, "to hexadecimal is: ",hexa)
