num = float(input("Enter a value for feet: "))
print("%.5f feet is %.5f meters" %(num,(num * .305)))
