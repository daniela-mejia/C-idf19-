miles= float(input(" How many miles have you driven?: "))
gallons= float( input (" How many gallons of gas had you use?: "))
MPG = miles/gallons
print(" This is the amount of Mile-Per-Gallon you used: %.2f" % (MPG))
