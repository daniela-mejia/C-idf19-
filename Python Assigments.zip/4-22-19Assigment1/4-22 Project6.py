minutes= float(input("Number of minutes : "))
days =  minutes /1440
print ("Approx days: %.2f" % (days))
years = days/365
print("Approx %.2f years" %(years))
