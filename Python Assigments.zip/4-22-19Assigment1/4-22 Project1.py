# annual profit is typically 23 percent of total sales.
#ask for profit and write the amount of total sales. then times 0.23
num = int(input("Please Input Total Amount of Sales: "))
print(" Annual Profit is: ",(num * .23))
