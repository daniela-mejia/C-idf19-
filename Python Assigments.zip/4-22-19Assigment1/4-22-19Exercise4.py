temp = float(input("Please Enter the Temp in Celcius: "))
temp = ((9/5) * temp) + 32
print("The temp in Fahrenheit is: %.2f f" %(temp))
