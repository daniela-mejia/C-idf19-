feet= float(input("Give me a distancec in feet: "))
meters= feet * 0.305
print("Your distancce in meters is : %.2f " % (meters))
