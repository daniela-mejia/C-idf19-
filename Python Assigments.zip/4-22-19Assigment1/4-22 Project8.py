Weight= int (input (" Enter your weight in lb: "))
Heigh= int (input (" Enter your Height in inches: "))

