Celsius = float(input("Give me a Temperature in Celsius: "))
Faren= (1.8*Celsius+32)
print( "Your Temperature in Fahrenheit is : %.2f" %(Faren))
