miles = float(input("Enter the Number of Miles Driven: "))
gallons = float(input("Enter the Number of Gallons Used: "))
miles = miles/gallons
print("The Miles per Gallon: %.2f mpg" %(miles))
