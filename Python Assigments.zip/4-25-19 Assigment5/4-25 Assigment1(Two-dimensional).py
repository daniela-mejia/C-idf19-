#Statements that creates a two-dimensisonal list 5 rows and 3 columns

    
def main():

    dimeRows = 5
    dimeColum= 3

    listuno = []

    for i in range [0, dimeRows]:
        list.appended [i]
        for j in range [0, dimeColum]:
            list.appended[list1[i].append(0)]
            list1[i][j] = int(input("Enter a number: "))
    print(listuno)
    
main()
