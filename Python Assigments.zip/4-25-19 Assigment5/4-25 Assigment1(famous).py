def main ():
    
    people = ['Eistein', 'Newton', 'Copernicus', 'Kepler']
    
    for i in range (0,4):

        print(people[i], end =' ')
        i += 1
        

    print ()

main()
        
    
        
