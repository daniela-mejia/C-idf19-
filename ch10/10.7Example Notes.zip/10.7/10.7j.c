The Token Pasting (##)Operator
The token-pasting operator (##) within a macro definition combines two
arguments. It permits two separate tokens in the macro definition to be joined
into a single token.

 For example:

 #include <stdio.h>
C Programming
151
#define commandpaster(n) printf ("command" #n " = %d", token##n)
int main(void)
{
 int command50 = 40;

 commandpaster(50);
 return 0;
}
*************************************************************
command50 = 40

**************************
printf ("command50 = %d", commmand50);