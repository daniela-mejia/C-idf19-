The Defined() Operator

The preprocessor defined operator is used in constant expressions to determine
if an identifier is defined using #define. If the specified identifier is defined, the
value is true (non-zero). If the symbol is not defined, the value is false (zero).
The defined operator is specified as follows:

#include <stdio.h>
#if !defined (MESSAGE)
 #define MESSAGE "Building!"
#endif
int main(void)
{
 printf("Here is the message: %s\n", MESSAGE);
 return 0;
}

Here is the message: Building!
