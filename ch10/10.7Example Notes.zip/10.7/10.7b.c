EXAMPLE PROGRAM FOR #IFDEF, #ELSE AND #ENDIF IN C:
“#ifdef” directive checks whether particular macro is defined or not. If it is defined, 
“If” clause statements are included in source file.
Otherwise, “else” clause statements are included in source file for compilation and execution.

**********************************************************
#include <stdio.h>
#define STUFF 100
 
int main()
{
   #ifdef STUFF
   printf("STUFF is defined. So, this line will be added in " \
          "this C file\n");
   #else
   printf("STUFF is not defined\n");
   #endif
   return 0;
}
*************************************************************

STUFF  is defined. So, this line will be added in this C file