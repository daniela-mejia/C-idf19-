
************************************
#ifdef DEBUG
 /* Your debugging statements here */
#endif
*******************************************
It tells the CPP to process the statements enclosed if DEBUG is defined. 

This is useful if you pass the -DDEBUG flag 
to the gcc compiler at the time ofcompilation. 

This will define DEBUG,so you can turn debugging on and off onthe-fly during compilation.