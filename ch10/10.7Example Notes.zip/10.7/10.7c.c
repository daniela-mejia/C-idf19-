EXAMPLE PROGRAM FOR #IFNDEF AND #ENDIF IN C:
#ifndef exactly acts as reverse as #ifdef directive. If particular macro is not defined,
 “If” clause statements are included in source file.
Otherwise, else clause statements are included in source file for compilation and execution.

*******************************************************
#include <stdio.h>
#define STUFF 100
int main()
{
   #ifndef XYZ
   {
      printf("XYZ is not defined. So, now we are going to " \
             "define here\n");
      #define XYZ 300
   }
   #else
   printf("XYZ is already defined in the program”);
 
   #endif
   return 0;
 
}

XYZ is not defined. So, now we are going to define here


