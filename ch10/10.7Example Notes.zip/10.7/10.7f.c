EXAMPLE PROGRAM FOR PRAGMA IN C LANGUAGE:
Pragma is used to call a function before and after main function in a C program.

**********************************************
#include <stdio.h>
 
void function1( );
void function2( );
 
#pragma startup function1
#pragma exit function2
 
int main( )
{
   printf ( "\n Now we are in main function" ) ;
   return 0;
}
 
void function1( )
{
   printf("\nFunction1 is called before main function call");
}
 
void function2( )
{
   printf ( "\nFunction2 is called just before end of " \
            "main function" ) ;"
			
			
*****************************************************
Function1 is called before main function call
Now we are in main function
Function2 is called just before end of main function
*************************************************************

#include <stdio.h> 
  
void func1(); 
void func2(); 
  
#pragma startup func1 
#pragma exit func2 
  
void func1() 
{ 
    printf("Inside func1()\n"); 
} 
  
void func2() 
{ 
    printf("Inside func2()\n"); 
} 
  
int main() 
{ 
    void func1(); 
    void func2(); 
    printf("Inside main()\n"); 
  
    return 0; 
} 
*******************************************
Output:
*********************************************

Inside func1()
Inside main()
Inside func2()
***********************************************

The above code will produce the output as given below when run on GCC compilers:
*******************************
Inside main()
***********************************
This happens because GCC does not supports #pragma startup or exit


