The Stringize (#)Operator
The stringize or number-sign operator (#), when used within a macro definition,
converts a macro parameter into a string constant. This operator may be used
only in a macro having a specified argument or parameter list. 

For example:

#include <stdio.h>
#define message_for(a, b) \
 printf(#a " and " #b ": How are you\n")
int main(void)
{
 message_for(John, Janet);
 return 0;
}

*********************************************

John and Janet: How are you
*******************************************