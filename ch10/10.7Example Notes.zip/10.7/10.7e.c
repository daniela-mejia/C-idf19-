EXAMPLE PROGRAM FOR UNDEF IN C LANGUAGE:
This directive undefines existing macro in the program.

&********************************
#include <stdio.h>
 
#define height 100
void main()
{
   printf("First defined value for height    : %d\n",height);
   #undef height          // undefining variable
   #define height 600     // redefining the same for new value
   printf("value of height after undef \& redefine:%d",height);
}

First defined value for height : 100
value of height after undef & redefine : 600