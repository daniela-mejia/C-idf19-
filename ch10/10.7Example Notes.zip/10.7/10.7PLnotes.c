

EXAMPLE OF CONDITIONAL COMPILATION

/* Returned by various functions on end of file condition or error. */
#define	EOF	(-1)
 
/*
 * The maximum length of a file name. You should use GetVolumeInformation
 * instead of this constant. But hey, this works.
 * Also defined in io.h.
 */
#ifndef FILENAME_MAX
#define	FILENAME_MAX	(260)
#endif
 
 
 
 
/*
 * The maximum number of files that may be open at once. I have set this to
 * a conservative number. The actual value may be higher.
 */
#define FOPEN_MAX	(20)
#########################################################################################3
#include <stdio.h>
#define FILENAME_MAX (60)
int main()/*  www.weyu.com */
{
    printf(" %u \n", FILENAME_MAX);

    return 0;
}
